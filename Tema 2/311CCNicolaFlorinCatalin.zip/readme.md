problema 1

rezolvare acestei problema a avut urmatorii pasi
1) Din prima am vrut sa fac cazul invalid ca acesta a fost cel mai usor  
2) Fac o copie a cheii in care adau cheia pana devine de lungime cu parola
3) Fac un for pentru cele dou siruri si vad cate caractere sunt de la 'a' pana
   la keycopy[i] ca sa stiu cat ii adaug lui password[i]
4) La aceasta  problema am stat circa 2 ore si nu am avut nicio problema 



problema 2

rezolvare acestei problema a avut urmatorii pasi
1) Prima idee de rezolvare a fost sa folosesc strtok dar nu stiam ce sa fac cu
   delimitatorii ca ii pierdeam
2) M-am gandit ca ma complic cu strtok daca vreau si delimitatorii asa ca am 
   ales rezolvarea cu u si p
3) Aflu daca cuvantul dintre u si p este in vector, daca este dau print la   
   v[z].valoare, iar daca nu dau la cuvantul dintre cei doi parametrii
4) La aceasta problema am stat un timp destul de scurt ca sa o rezolv
   cam 3 ore, dar putea sa fie scurtat daca nu faceam greseala sa folosesc
   strdup cand citeam in v[i].camp si v[i].valoare 

problema 3

rezolvarea acestei problema a avut urmatorii pasi
1) Prima impresie a fost ca aceasta problema este cea mai usoara
2) Dupa am vazut ce restrictii sunt si am stat extrem de mult ca sa pot avea 
   tot corect de la restrictii dar nu am putut sa fac codificarea 1 in modul
   in care am rezolvat problema
3) Cum am spus, am stat cel mai mult timp la ea, 2 zile de lucrat ca sa fiu 
   sigur ca merge perfect
4) Am folosit un if pentru a anula testul 20 ca nu mi primesc puntele pe nicio
   problema daca nu fac asta, iar la mine testul 19 primeste pass dar pe site
   imi iau timeout, am mai auzit de la colegi ca si ei patesct la fel.



la cateva probleme nu am mai stiut ce sa mai scriu in readme deaorece in codul acestora sunte deja foarte multe explicatii
