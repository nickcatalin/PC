//rezolvata la laborator
