
typedef struct Produs
{
    char nume_produs[21];
    int cantitate;
    float pret_produs;
} Produs;
int func(int a);
void creare_fisier(char *nume_fisier);
void afisare_ecran(char *nume_fisier);
