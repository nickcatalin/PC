#include <stdio.h>
#include <Produs.h>

long ana(int n)
int main()
{
}