problema 1

rezolvare acestei problema a avut urmatorii pasi
1) am rezolvat pentru interogarea simpla deoarece la cea compusa erau pasii asemanatori
2) am adaptat pasii de la interogarea simpla la cea compusa , tinand cont ca sunt  mai multe operatii
3) la functii a fost mai greu pana mi am amintit ca in trecut am mai avut o problema 
   cu reuniunea si intersectia  dintre doua intervale si am facut la fel
4) in rest am respectat toti pasii problemei, acestia fiind si explicati in fisierul problemei   



problema 2

rezolvare acestei problema a avut urmatorii pasi
1) functiile au fost facute inca de la inceput 
    prima fiind strrev deaorece in linux nu merge fara sa o construiesti 
2) am facut teste pentru fiecare dintre functii ca pe viitor sa nu ma intreb care dintre acestea este gresita si sa nu pierd timp
3) in rest am respectat toti pasii problemei, acestia fiind si explicati in fisierul problemei 

problema 3

rezolvarea acestei problema a avut urmatorii pasi
1) functiile au fost facute inca de la inceput 
2) am facut teste pentru fiecare dintre functii ca pe viitor sa nu ma intreb care dintre acestea este gresita si sa nu pierd timp
3) in rest am respectat toti pasii problemei, acestia fiind si explicati in fisierul problemei 



problema 4

rezolvarea acestei problema a avut urmatorii pasi
1) am numarat cati soldati sunt pe fiecare linie si am salvat acest numar impreuna cu numarul liniei
2) am ordonat numarul de soldati si implicit si numarul liniei pentru fiecare 
3) am afisat cele k linii slabe cum a fost cerut


la cateva probleme nu am mai stiut ce sa mai scriu in readme deaorece in codul acestora sunte deja foarte multe explicatii
